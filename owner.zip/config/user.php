<?php


return [
    'user_verified' => env("USER_VERIFIED",true),
];